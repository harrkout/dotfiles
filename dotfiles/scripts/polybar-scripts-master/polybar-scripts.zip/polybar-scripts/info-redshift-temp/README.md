# Script: info-redshift-temp

This script displays the current color temperature.

![info-redshift](screenshots/1.png)


## Module

```ini
[module/info-redshift-temp]
type = custom/script
exec = ~/polybar-scripts/info-redshift-temp.sh
interval = 5
```
