# Script: news-archlinux

A Python script that shows Arch Linux RSS news.


## Dependencies

* [python-feedparser](https://github.com/kurtmckee/feedparser//)


## Module

```ini
[module/news-archlinux]
type = custom/script
exec = ~/polybar-scripts/news-archlinux.py
interval = 600
```
