# Script: info-pingrtt

A script that displays a ping result. It also shows a colored icon.

![info-pingrtt](screenshots/1.png)
![info-pingrtt](screenshots/2.png)
![info-pingrtt](screenshots/3.png)


## Module

```ini
[module/info-pingrtt]
type = custom/script
exec = ~/polybar-scripts/info-pingrtt.sh
interval = 10
```
