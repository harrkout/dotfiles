# Script: info-eyestrain

A script for avoiding digital eye strain.

It follows the 20-20-20 rule. The timer displays how long it is until the next break. You can add this to send a notification and play a sound when the time is up.


## Module

```ini
[module/info-eyestrain]
type = custom/script
exec = ~/polybar-scripts/info-eyestrain.sh
interval = 60
```
